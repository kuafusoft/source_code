// JavaScript Document
var kf = {
	create : function(){
		var kf = {
			params:{},
			getParams : function(name){
				var ret;
				if (name == null || name == undefined)
					ret = this.params;
				else if($.isArray(name)){
					for(var i in name){
						ret[name[i]] = this.params[name[i]];
					}
				}
				else{
					ret = this.params[name];
				}
				return ret;
			},
			setParams : function(p){
				p = p || {};
				for(var i in p){
					this.params[i] = p[i];
				}
				return this.params;
			},
			resetParams: function(p){
				for(var i in p){
					delete this.params[p[i]];
				}
				return this.params;
			}
		};
		return kf;
	}
};

var db_table = {
	create : function($db, $table){
		var db_table = {
			params:{db:$db, table:$table},
			getParams : function(name){
				var ret;
				if (name == null || name == undefined)
					ret = this.params;
				else if($.isArray(name)){
					for(var i in name){
						ret[name[i]] = this.params[name[i]];
					}
				}
				else{
					ret = this.params[name];
				}
				return ret;
			},
			setParams : function(p){
				p = p || {};
				for(var i in p){
					this.params[i] = p[i];
				}
				return this.params;
			},
			resetParams: function(p){
				for(var i in p){
					if (p[i] != 'db' && p[i] != 'table')
						delete this.params[p[i]];
				}
				return this.params;
			},
			hello: function(){
				alert(this.params['db'] + ':' + this.params['table']);
			}
		};
		return db_table;
	}
};
