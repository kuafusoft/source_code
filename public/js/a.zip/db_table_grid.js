var db_table_grid = {
	create : function($db, $table){
		var grid = db_table.create($db, $table);
		
		grid.genId = function(){};
		grid.handleOptions = function(options){
			var defaultOptions = {
				gridOptions:{
					pagerpos:'center',
					datatype:'json',
					ajaxSelectOptions:{type:'POST'},
					ajaxGridOptions:{type:'POST'},
					altRows:true,
					altclass:'ui-priority-secondary',
					mtype: 'POST',
					cellEdit: false,
					cellsubmit:'remote', 
					hiddengrid:false,
					multiselect:true,
					multiboxonly:false,
	//				rownumbers:true,
					rowNum:25, 
					rowList:[10, 25, 50, 100, 200, 'ALL'], 
					shrinkToFit:true,
					forceFit:true,
					sortorder:"asc", 
					loadonce:false,
					autowidth:true,
					width:'1200',
					height:'auto',
	toppager:true,
					keyIndex:'id',
					viewrecords:true,
					jsonReader:{
						root:'rows',
						page:'page',
						total:'pages',
						records:'records',
						repeatitems:false,
						cell:''
					},
					treeGridModel:'nested'
				},
				navOptions:{add:false, view:false, edit:false, search:false, del:false, cloneToTop:true},
				menuOptions:{view:true, edit:true, del:false, clone:false}, // context
				editOptions:{
					top:100, left:200, width:600, closeOnEscape:true, closeAfterEdit:true, reloadAfterSubmit: false,
					bottominfo:"Fields marked with (*) are required"
				},
				addOptions:{
					top:100, left:500, closeOnEscape:true, bottominfo:"Fields marked with (*) are required",
					afterSubmit:function(response, postdata){
						var ret = $.parseJSON(response.responseText);
						if (ret.code == 1){
		//                    alert(ret.msg);
							return [false, ret.msg, 1];
						}
						return [true, 'Success to save the record', ret.msg];            
					}
				},
				delOptions:{
					top:100, 
					left:500
				},
				viewOptions:{
					top:100, left:500, width:600, closeOnEscape:true
				},
				buttons:{},
				contextMenu:'',
				lastSel: 0
			};
		//xt.debug(options);    
			var config = $.extend(true, defaultOptions, options);	
			config = this.prepare(config);
			$.each(config.gridOptions.colModel, function(i, v){
				if (v.label == undefined)
					v.label = ucwords(v.name);
				if (v.index == undefined)
					v.index = v.name;
			});			
			if (!config.gridOptions.multiselect)
				delete(config.gridOptions.buttons['tag']);

			config.gridOptions.resizeStop = config.gridOptions.resizeStop || function(newWidth, index){
				this.saveDisplayCookie(config);
			}; 

			config.gridOptions.sortable = config.gridOptions.sortable || { 
				update: function(permutation) {
					this.saveDisplayCookie(config);
				}
			};
			if (typeof config.gridOptions.treeGrid != 'undefined' && config.gridOptions.treeGrid)
				config.gridOptions.rowNum = -1;
			if (config.gridOptions.inlineEdit == undefined || (config.gridOptions.inlineEdit == 'true' || config.gridOptions.inlineEdit == true)){
				config.gridOptions.ondblClickRow = function(rowid, iRow, iCol, e){
					var gridId = this.getParams('gridId');
			//xt.debug([rowid, iRow, iCol, e]);
					if(rowid && rowid!==config.lastSel){ 
						jQuery(gridId).restoreRow(config.lastSel); 
						config.lastSel=rowid; 
					}
					jQuery(gridId).editRow(rowid, true); 
				}
			}
XT.debug(config);			
			return config;
		};
		
		grid.init = function(options){
			this.genId();
			var gridId = this.getParams('gridId');
			var pagerId = this.getParams('pagerId');
			if (options.getConfig != undefined && options.getConfig == true){
				$.ajax({
					url:options.config.url,
					type:'POST',
					data:options.config.data,
					dataType:'json',
					success:function(retData, textStatus){ // get the colModels
						options = $.extend(true, retData, options);
XT.debug(options);					
						this.setup(options);
					},
					error:function(XMLHttpRequest, textStatus, errorThrown){
						alert("error:" + textStatus);
					}
				});
			}
			else{
				this.setup(options);
			}
		};
		
		grid.setup = function(options){
			var db = this.getParams('db'), tb = this.getParams('table');
			var allOptions = this.handleOptions(options);
			var button_nav = pagerSelector + "_left";
			var button_select =  button_nav.substr(1) + "_buttons";
			var tagSearch_select = button_nav.substr(1) + '_tagSearch';
			var gridSelector = this.getParams('gridId');

			allOptions.gridOptions.pager = pagerSelector;
			$(gridSelector).jqGrid(allOptions.gridOptions);
			
			var navGrid = $(gridSelector).jqGrid('navGrid', pagerSelector, allOptions.navOptions, allOptions.editOptions, allOptions.addOptions,
				allOptions.delOptions, allOptions.searchOptions, allOptions.viewOptions);
			var buttons = Object.keys(allOptions.buttons).length, maxButtons = 4;
			var postData = allOptions.gridOptions['postData'];
			var parentId = postData['parent'] || 0;
			if (parentId == 0 && postData['filters'] != undefined){
				var filters = JSON.parse(postData['filters']);
				var rules = filters['rules'];
				parentId = rules[0]['data'];
			}
				
			if (buttons > maxButtons)
				$(button_nav + " tr").append("<td><select id='" + button_select + "' style='width:120px'><option id='no_op' value='no_op' class='option_gray'>=Select Action=</option></select></td>");
			if (allOptions.tags != undefined){
				//附加Tag Search
				$(button_nav + " tr").append("<td><select id='" + tagSearch_select + "' style='width:120px'></select></td>");
			}
			
			for(var key in allOptions.buttons){
				if (key == 'add'){
					navGrid.navButtonAdd(pagerSelector, {caption:'', id:'add_'+ db + '_' + tb, 'title':'Add a new record', onClickButton:function(){
	//					$this.newElement(gridSelector, db, tb, parentId);
						$this.information(gridSelector.substr(1), 0, parentId);
					}});
					$(pagerSelector + ' #add_' + db + '_' + tb + ' span').addClass('ui-icon-plus');
					continue;
				}
				
				if (allOptions.buttons[key]['onClickButton'] == undefined){
					allOptions.buttons[key]['onClickButton'] = 'buttonActions';
				}
				if (typeof allOptions.buttons[key]['onClickButton'] == 'string'){
					try{
						allOptions.buttons[key]['onClickButton'] = this.createFunction($this, allOptions.buttons[key]['onClickButton'], key, gridSelector, allOptions);
					}catch(e){
						alert('Fail to create function for button click');
					}
				}
				if (buttons > maxButtons && key != 'columns' && key != 'export'){
					$('#' + button_select).append("<option id='" + key + "' value='" + key + "'>" + allOptions.buttons[key]['caption'] + "</option>");
				}
				else
					navGrid.navButtonAdd(pagerSelector, allOptions.buttons[key]);
			}
			if (buttons > maxButtons){
				$('#' + button_select).bind('change', allOptions, function(event){
					var op_id = $(this).children('option:selected').val();
					$(this).children('#no_op').attr('selected', 'selected');
					$this.buttonActions(op_id, gridSelector, event.data);
				});
			}

			if (allOptions.tags != undefined){
				// fill out the tags for tag search
				$this.fillTagOptions(tagSearch_select, allOptions.tags);
				// bind the event for tag search
				(function () {
					$('#' + tagSearch_select).focus(function () {
						// Store the current value on focus and on change
						previousTag = this.value;
					}).bind('change', allOptions, function(event){
						// Do something with the previous value after the change
						var op_id = $(this).children('option:selected').val();
						$this.tagSearchActions(op_id, gridSelector, event.data, tagSearch_select);

						if (op_id !== 'refresh_tag'){
							previousTag = op_id;
						}
					});
				})();
			}
			
		//xt.debug(config.gridOptions);	 

		//    $(gridId).jqGrid('sortableRows'); 

			// check if the query div exist, if existed, then do not use toolbar search
	//		if ($('#' + db + '_' + tb + '_cond').html().trim() == '' &&
			if (allOptions['gridOptions']['search'] == undefined || allOptions['gridOptions']['search'] == true)
				$(gridSelector).jqGrid('filterToolbar');
			if (allOptions['sortableRows'])
				$(gridSelector).jqGrid('sortableRows');		
		};
		
		grid.load = function(postData, p_db, p_table, p_id){
			var data = this.getParams();
			postData = postData || {};
			for(var i in postData){
				data[i] = postData[i];
			}
			var editurl = '/jqgrid/jqgrid/db/' + db + '/table/' + table;
			if (p_db)
				editurl += '/parentdb/' + p_db;
			if (p_table)
				editurl += '/parenttable/' + p_table;
			if (p_id)
				editurl += '/parent/' + p_id;
			var options = {
				getConfig:true,
				config:{
					url:'/jqgrid/jqgrid',
					data:$.extends({oper:'getGridOptions'}, data),
				},
				gridOptions:{
					url:'/jqgrid/list',
					postData:data,
					editurl:editurl
				},
				editOptions:{
					
				}
			};
			return this.init(options);
		};
		
		grid.index = function(){
			tabTitle = tabTitle || db + ' ' + table;
			var div4Tab = getDiv4Tab();
			var url = '/jqgrid/index/db/' + db + '/table/' + table;
			var tabId = tabTitle.replace(/ /g, '');
			var base = div4Tab + '_' + db + '_' + table;
			var conditionSelector = base +'_cond';
	//alert(div4Tab);		
	//	xt.debug(gridId);
	//	xt.debug(pagerId);
			var events = {
				tabsload:function(event, ui){    
					if (ui.tab.id == tabId){
	//debug(conditionSelector);
						if ($(conditionSelector).html() != null && $(conditionSelector).html().trim() == ''){
							var gridSelector = base + '_list', pagerSelector = base + '_pager';
							return $this.grid_load(gridSelector, pagerSelector, db, table);
						}
					}
					return false;
				}
			};
			return this.newTab(url, div4Tab, tabTitle, events);
		};

		grid.prepare = function(){};
		grid.expandSubgrid = function(){};
		grid.buttonActions = function(action, gridId, options){};
		grid.contextMenu = function(){};
		grid.query = {
			init: function(){},
			reset: function(){}
		};
		grid.information = {
			init: function(){},
			open: function(){},
			close: function(){}
		};
		grid.view_edit = {
			init: function(){},
			view: function(){},
			edit: function(){},
			cancel: function(){},
			save: function(){},
			cloneit: function(){},
			saveAndNew: function(){}
		};
		
		return grid;
	}
};
