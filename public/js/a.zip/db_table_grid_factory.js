var db_table_grid_factory = {
	objs: {},
	get: function($db, $table){
		if (this.objs[$db] == undefined)
			this.objs[$db] = {};
		if (this.objs[$db][$table] == undefined){
			XT.loadFile('js/db_table.js', 'js');
			XT.loadFile('js/db_table_grid.js', 'js');
			try{
				var funName = $db + '.' + $table + '.create';
				this.loadJS($db, $table);
				this.objs[$db][$table] = eval(funName)();
alert(funName);				
			}catch(e){
				this.objs[$db][$table] = db_table_grid.create($db, $table);
			}
		}
		return this.objs[$db][$table];
	},
	getJS: function($db, $table){
		var jsFile = 'js/' + $db + '/' + $table + '.js';
		return jsFile;
	},
	loadJS: function($db, $table){
		XT.loadFile('js/' + $db + '.js', 'js');
		var jsFile = this.getJS($db, $table);
		XT.loadFile(jsFile, 'js');
	}
};